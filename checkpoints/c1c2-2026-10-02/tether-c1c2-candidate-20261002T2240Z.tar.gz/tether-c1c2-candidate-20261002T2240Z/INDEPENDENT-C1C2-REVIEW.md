# Independent final bounded C1/C2 review

Reviewed 2026-10-02 at 22:40 UTC. Base: rebuilt-S commit a514c0f7f95f6df1bb987bee315830261b5c6188. Verdict: acceptable to archive and deliver as a bounded functional implementation checkpoint, with the explicit incomplete lifecycle witness below. This is not certification of the entire mechanism milestone, subjective experience, acquired transfer, calibrated probability, or competitive efficacy.

## Independently verified final results

- Full current suite: **264/264 passed, zero skipped** (`independent-final-full.log`).
- Focused C1/C2 suite: **75/75 passed, zero skipped**, including 11 coordination checks with native-controller causal fixtures (`independent-final-focused.log`).
- Arithmetic audit and `git diff --check`: passed. Arithmetic sampling is not a proof of correct rounding.
- The archived historical affect test matches `git show a514c0f:test/affect.test.mjs` byte-for-byte: SHA-256 `3286197484c6b4d1bd910c52bf27b1a428dec9dfcd19e96f4fa12a71a1f99789`.
- The parity worker separately verified a complete copy without `.git`, with `ORIGINAL_SOURCE` pointing to a nonexistent path: 264/264, zero skipped. This portability result is corroborating worker evidence; the independent final aggregate above ran in the candidate checkout.

Exact reviewed source, test, helper, manifest, status and plan bytes are listed in `independent-final-checkpoint.sha256`. Historical checkpoint logs/manifests remain separately labeled and do not identify this final revision.

## Mechanism assessment

Validated immutable selected hypotheses route through separate attention, planner, episodic-memory and report delivery boundaries. Content changes alter native planner targets and emitted control at fixed focus. A one-time encoding intervention is removed before disappearance; later genuine retrieval changes control, write/read cuts remove that influence, and restoration reproduces intact actions. Attention has a separate actual gaze/control effect with immediate planner/memory recipients unchanged. Tests now compare all delayed-input prefixes and prior decisions through the causal boundary, limiting indirect-divergence explanations.

Monitor timing is faithful to the agreed contract: delayed percept clock, settlement before replacement, frozen hypothesis anchor distinct from evidence time, one disposition per forecast, due .3 seconds, expiry 1 second, unique increasing sensory evidence, EWMA .25, unknown until two assessments and high-error strictly above .5 world units. Feedback-cut proposals are computed but not committed to aggregate or transient control; control cuts retain monitored evidence while suppressing delivery.

The identical legal-percept replay demonstrates pre-outcome prediction error, attention/replanning, actual control effects, later corrective evidence, changed issued forecast velocity and low-error recovery. These are yoked controller mechanism checks, not independent closed-loop efficacy outcomes. Frozen-learning replay preserves whole persisted memory while transient surprise still changes control; report/trace sinks preserve actions and whole memory.

## Historical regression replacement review

The obsolete whole-controller noAffect/original-v2 identity assertion is explicitly preserved in an archived file and replaced with two accurately scoped tests:

1. Swap only the original workspace into otherwise identical current modules, then require exact noAffect action/replay parity.
2. Disable coordination and require exact rebuilt-S parity against its complete frozen 11-module controller import closure, across both modes/seats and four fixed configurations. Replay, memory, cognition, settings and legacy self-report match; added trace fields are separately inspected rather than silently stripped to claim whole-trace parity.

Frozen bytes and their manifest are pinned and verified before imports; tests reject altered fixture bytes or manifest. Current tests do not fall back to current code for missing baselines, depend on adjacent checkouts, or require historical Git objects. Helper and fixture documentation accurately disclose that simulation/perception/logging are current and common to the controller comparison arms.

## Explicit remaining gap and boundaries

A native witness where an organically created, non-null pending recall plan is subsequently invalidated by monitor correction remains absent. Source clears such a plan on monitor forcing, and native replanning/action influence is demonstrated, but those facts do not establish the narrower pre-existing-plan lifecycle witness. The checkpoint correctly states that the full mechanism milestone is not certified complete. No privileged actuator injection or expanded search was used to obscure this gap.

The 16 coordination work units are declared nominal accounting, not full-engine cost equivalence. `C1C2-STATUS.md` accurately states the tested scope, historical provenance limitations and missing witness without claiming transfer or consciousness. No fresh acquisition/transfer experiment, remote publication, or closed N/S evidence modification was performed by this review. Archive this candidate before any separately authorized study; freeze its protocol separately.
