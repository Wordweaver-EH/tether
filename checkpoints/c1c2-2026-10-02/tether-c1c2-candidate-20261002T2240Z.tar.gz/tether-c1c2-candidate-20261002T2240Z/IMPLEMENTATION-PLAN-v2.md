# Bounded C1/C2 target-hypothesis milestone: implementation and unit-test plan

Status: agreed implementation/unit plan frozen before code; version 2 incorporates the assessor temporal/recovery contract. Functional operationalization only; neither module names nor this milestone establish subjective experience. No acquisition/transfer study or comparative performance outcome is authorized by this plan.

## Base and scope

Create a separate local candidate from rebuilt S commit a514c0f7f95f6df1bb987bee315830261b5c6188. Preserve all N/S sources, closed measurements, manifests and Library versions unchanged. Work under persistent tether-c1c2. Game rules, sensor/motor cadence, basic physical constants, planner horizon and hit-radius constants do not change. B's blocked full-engine accounting is independent; new work must be explicitly visible, not claimed free.

One target-tracking / disappearance / reacquisition loop is the milestone. Existing reflex/local routes remain. No win-rate threshold or consciousness score is used.

## Structured selected content

A selected specialist supplies a symbolic referent. Its workspace winner produces one immutable structured content packet, not a precomputed actuator command. Fields: revision and evidence IDs, focus label, entity, mean/velocity hypothesis, uncertainty, source (observed, predicted or episodic), original evidence time, issuance time, age/validity and parent provenance. Recalled or predicted content cannot become a new sensory observation or increase evidence counts merely by rebroadcasting.

Independent consumers receive the same packet through explicit delivery boundaries:
1. Attention: selected entity/position changes inspection priority and reacquisition target, rather than just copying the motor command.
2. Episodic target memory: bounded structured write and later entity-based read after disappearance. Retrieved provenance/age survives, and the recalled hypothesis can enter a later selection/planning cycle. Memory feedback must not double-count self-generated content as fresh evidence.
3. Planner: payload mean/velocity/uncertainty changes the target hypothesis and resulting branch evaluation/plan revision independently of attention or report. No payload field directly selects a throw or recall.
4. Grounded report: actual delivered content, source/age, monitor forecast/error status and planner completion/bounds. Available with trace capture off. Reporting is a sink; disabling it cannot change actions or memory-based control.

Focus labels remain held fixed in content-intervention tests. Entity/content changes must propagate through actual computation, not route-name changes or observer-only logs.

## Prediction-reliability feedback loop

Add a bounded monitor of this target predictor, distinct from novelty familiarity and branch completion. Freeze position/velocity/source/time before any scoring observation. Agreed fixed timing contract: one pending forecast, due after 0.3 seconds; first visible observation at or after due and at most 1.0 seconds after issuance can assess the already frozen linear forecast. A missing observation at expiry is censored, not an error or success. Track actual assessment horizon. No after-the-fact fitted forecast.

Maintain empirical prediction discrepancy and explicit unknown state until evidence exists. Reliability is not claimed to be a calibrated hit probability. Agreed fixed engineering constants: error EWMA alpha 0.25, minimum two assessed predictions for a known reliability category, spatial-error threshold 0.5 world units. An individual observed large discrepancy can request inspection/replanning without inventing numerical certainty. These constants and the recovery rule below are frozen before unit fixtures and will not be tuned against held-out outcomes.

The monitor's control request is consumed by attention reacquisition and by planner escalation/plan invalidation. Later visible evidence updates the monitor and the next forecast/control decision. Ordinary clear/easy tracking and a misleading/occluded target must be representable without injected successes.

Separate intervention boundaries:
- feedback to monitor: compute discrepancy/update proposal but suppress its commitment to the governing monitor state
- monitor to control: compute/update the monitor and control recommendation but suppress the recommendation's delivery

Novelty support remains familiarity only; predictive reliability remains prediction-error evidence; unresolved completion remains bounded ignorance. They are never merged into one unlabeled confidence scalar.

## Controls and persistence

Recipient delivery lesions, memory write/read lesions, feedback/monitor-control lesions and restoration are explicit research controls, separate from the bundled noMetacog flag. Keep the relevant computations and diagnostics present when delivery is disconnected. Local/reflex fallbacks remain available, not replaced by a deliberately crippled policy.

The existing explicit freezeLearning option must freeze newly persisted monitor/episodic learned fields as well, without disabling lookup, belief, workspace, transient forecasts or plans. Default ordinary learning stays enabled. Research packet interventions must validate shape, provenance and finite values; no privileged simulator/evaluator state enters the controller.

## Unit acceptance before any fresh study

- Contract: immutable valid packets; malformed/future/stale payloads fail closed; no recalled content masquerades as fresh observation
- C1 routing: with identical focus label/input/seed, two content hypotheses cause relevant distinct attention, memory-read and planner effects; report agrees with received evidence
- Selective cuts: removing one recipient delivery removes its content-specific effect while immediate other consumers retain theirs; original delivery restoration reproduces intact state/actions
- Delayed memory: write, disappearance and later retrieval influence an actual later decision; independent write/read lesions remove that influence; restoration recovers it
- C2 temporal integrity: forecast exists before evidence; error is scored once, missing evidence is censored, update/recovery changes subsequent prediction/control without after-the-fact leakage
- Separate C2 lesions: feedback cut breaks reliability update; control cut preserves update but breaks its choice effect; both restore independently
- Real-mind integration: requests alter attention/planning/actual emitted control, not only logger fields; known local/reflex routes survive
- Report independence: trace on/off and report sink on/off preserve actions; grounded report remains available when traces are off
- Persistence: bounded storage, detached snapshots, safe loading, whole-memory freeze invariant
- Full existing suite: retain historical checks; report any invalid cross-build identity assertion explicitly for separate review rather than silently weakening it

Seeded wiring fixtures and ordinary learned/calibration witnesses are labeled separately. Unit fixtures establish mechanism contracts, not acquired transfer. Fresh acquisition, held-out geometries/delays/motions and intervention/restoration outcome runs need a separately frozen protocol, source review, byte manifest and durable backup before execution.

## Deliverable and stopping boundary

First deliver source proposal/interfaces plus unit regressions, full test result and source diff for independent review. Archive source/protocol/tests in Library before any fresh study. No remote publication, no modification of the closed N/S evidence, no outcome-driven tuning. If any required causal witness fails, the mechanism milestone remains unfinished.

## Agreed temporal/recovery clarification (pre-code)

All clocks use delayed percept.time.elapsedSec, never the live simulator or wall clock. A frozen forecast anchors position at its explicit hypothesisTime, distinct from originalEvidenceTime. Assess the frozen p + v * (assessmentTime - hypothesisTime), and retain the actual assessment horizon. Settle the existing forecast before issuing a replacement; never score a just-created forecast.

One pending forecast produces one scored or censored disposition. Sensory observation evidence IDs/timestamps must increase uniquely. Repeated act ticks, pre-due observations, rebroadcasts and episodic/predicted packets cannot duplicate an assessment or overwrite the frozen prediction. A valid visible sample at elapsed exactly1.0 seconds may score; after1.0 it expires regardless of visibility. A pre-due sample does not settle the forecast.

Initialize error EWMA from the first actual discrepancy, then use0.75*old+0.25*new. Category is unknown until two assessments, then high-error iff EWMA>0.5; equality is not high. An individual fresh discrepancy>0.5 can request reacquisition/replanning on that update; otherwise requests follow the high-error state. Censoring neither improves nor worsens empirical reliability. Two sequential assessments are correlated observations, not independent evidence or calibrated probabilities. Unknown and censor status remain visible in reports.
