import subprocess,time,pathlib,json,hashlib,platform,os
root=pathlib.Path(__file__).parent
start=time.monotonic();rows=[]
for level in range(6):
 remaining=45-(time.monotonic()-start)
 if remaining<=0:rows.append({'level':level,'status':'global-timeout-not-started'});continue
 t=time.monotonic();out=root/'receipts'/f'level-{level}.jsonl';err=root/'receipts'/f'level-{level}.stderr'
 with out.open('w') as f,err.open('w') as e:
  try:r=subprocess.run(['node',str(root/'timing.mjs'),str(level)],stdout=f,stderr=e,timeout=min(5,remaining));status='completed' if r.returncode==0 else 'failed'
  except subprocess.TimeoutExpired:status='timeout'
 rows.append({'level':level,'status':status,'elapsedSeconds':time.monotonic()-t,'raw':str(out),'rawSha256':hashlib.sha256(out.read_bytes()).hexdigest()})
(root/'receipts'/'execution.json').write_text(json.dumps({'elapsedSeconds':time.monotonic()-start,'hardwareScope':{'platform':platform.platform(),'machine':platform.machine(),'cpuCount':os.cpu_count(),'cpuModel':next((l.split(':',1)[1].strip() for l in pathlib.Path('/proc/cpuinfo').read_text().splitlines() if l.startswith('model name')),'unknown')},'levels':rows},indent=2)+'\n')
