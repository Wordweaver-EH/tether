import {createRobustBaselineAgent} from './repo/src/agents/robust-baseline-agent.mjs';
import {POLICY_SEEDS} from './repo/src/agents/param.mjs';
const level=Number(process.argv[2]);
function view(){return {viewerId:'P1',time:{elapsedSec:1},scores:{P1:0,P2:0},own:{position:{x:-3,y:-1},velocity:{x:0,y:0},facing:{x:1,y:0},spear:{state:'HELD',position:{x:-3,y:-1},direction:{x:1,y:0}}},opponent:{position:{x:3,y:1},velocity:{x:0,y:.2},facing:{x:-1,y:0}},opponentSpear:{state:'HELD',position:{x:3,y:1},direction:{x:-1,y:0}},arena:{bounds:{minX:-8,maxX:8,minY:-5,maxY:5},obstacles:[]},cone:{halfAngleRad:Math.PI/3}};}
for(const fixture of ['open-held','obstacle-held','recently-hidden','embedded']){
 const agent=createRobustBaselineAgent(POLICY_SEEDS.direct,{seed:1729,level});const v=view();
 if(fixture==='obstacle-held')v.arena.obstacles=[{id:'A',minX:-1,maxX:0,minY:-.5,maxY:2}];
 if(fixture==='recently-hidden'){const prime=view();prime.time.elapsedSec=.9;agent.act(prime,1/30);v.opponent=null;}
 if(fixture==='embedded')v.own.spear={state:'EMBEDDED',position:{x:6,y:-1},direction:{x:1,y:0}};
 for(let i=0;i<120;i++){
  const cpuStart=process.cpuUsage(),wallStart=process.hrtime.bigint();agent.act(v,1/30);const wallNs=Number(process.hrtime.bigint()-wallStart),cpu=process.cpuUsage(cpuStart);
  process.stdout.write(JSON.stringify({level,fixture,phase:i<20?'warmup':'measured',iteration:i<20?i:i-20,wallNs,cpuUserUs:cpu.user,cpuSystemUs:cpu.system,work:agent.diagnostics()})+'\n');
 }
}
