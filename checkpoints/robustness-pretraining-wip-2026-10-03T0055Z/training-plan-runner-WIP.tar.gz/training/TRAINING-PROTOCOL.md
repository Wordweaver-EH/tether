# Tether robustness: training-only protocol v1

Status: awaiting source/interface review and hash lock. No training or gameplay outcomes have run under this protocol. Latest user order: finish conventional training-only tuning and freeze parameters before writing the final held-out-condition preregistration; then one mirrored development pilot with all arms; known 40/12 diagnostic early; final evaluation last. Do not treat a training lock as permission to run held-out conditions.

Prior exposure disclosure: earlier unexecuted v0.3 draft already listed proposed shift categories and exact obstacle coordinates/constants. Its dated files/hashes are retained, not erased or represented as unseen. No outcome was generated using them, and baseline selection cannot use them. This protocol contains only default current-SPEC conditions.

## Fixed current distribution and sensor contract

MODE_B, Full selection and mind training use 300-second bouts; screening uses predeclared 45-second truncated training episodes with unchanged physical rules. Default 16×10 arena/default obstacles, 12 u/s outbound and return, 360°/s turn, 120° FOV; 120 Hz simulation. Public controller physical assumptions remain 12/12. Shared I/O: 150-ms percept delay, 30-Hz decisions, identical counter-addressed Gaussian motor noise, one-tick throw/recall pulses. The four pre-existing opponents are directShooter, immediateRecaller, embedWaiter, spearRusher. Their source bytes are frozen. Both seats for every screening/selection seed. No shifted world overrides, new opponent styles, or outcome-directed change to roster.

The baseline is a fixed 21-parameter conventional policy with reactive dodging and transient belief tracking, without parameter learning or self-monitoring. Two additional conventional arms apply fixed-model useful tactical lookahead at training-calibrated compute settings. Existing mind mechanisms/parameters are never tuned. Measured cost is exploratory, not certified equal total compute. At most eight CPU workers, no GPU.

## Source and resource preflight, no gameplay selection

Freeze exact engine, perception, interface, param agent, useful-work planner, diagnostic instrumentation, this protocol, pure training plan/candidate generator and worker/runner source hashes before the first scored training task. Verify default-behavior parity and sensor/noise/queue constraints first. Existing source fingerprint is d490afd30119c0d6bfe03373055aeb21a797c6138f1ee744961988238b8948e7 before approved interface/removal hooks. Published original checkpoint 0a810b6c1edd291417a9c9f3d42984264445110e remains intact.

Useful-work grid (aimCount,moveCount,hypotheses,steps), horizon 1.2 s: (5,5,3,12), (9,9,5,24), (17,9,9,48), (33,17,17,48), (65,33,33,96). Freeze kernel/utility weights; all extra branches must contribute to scoring/selecting legal actions, with no padding. On an outcome-blind fixed legal-percept workload, warmed runtime, five timing trials, calibrate the median wall-decision time nearest 2× and 4× mind median using absolute log-ratio distance, lower setting on ties. Record CPU time secondarily, wall median/p95 and peak memory. If maximum useful work fails the target, freeze it and label the target unachieved; don't assert equal or achieved resources. Timing profiles cannot rank gameplay strength. Exact workload and calibration records are hashed into the training lock before scoring.

## Conventional optimization, exactly 128 candidates per arm

Three independently tuned conventional arms: ordinary, useful-2x, useful-4x. Each uses the same proposal sequence algorithm, task seeds and finite evaluation counts, but each arm's own current-condition scores determine its parents. The selected compute levels are fixed before optimization.

Eight generations × sixteen candidates. Generation 0: direct, anchor, historical Phase-4 es-74, es-43, es-18 vectors (exact source-record hashes retained), followed by eleven mutations cycling those five seeds. Generations 1–7: sixteen mutations round-robin from the preceding generation's top four. Mutation for each coordinate: clip(parent + .16*(u1+u2+u3+u4−2),0,1), deterministic xorshift32 seeded per arm/generation/slot. Duplicate vectors are evaluated, not skipped or replaced. No hidden extra optimizer calls.

Each candidate is screened against all four old opponents, both seats, one generation-specific training seed, each a 45-second screening episode. All candidates in a generation and all arms share that generation's environment/motor seed; controller internal seed is likewise paired. Thus 1,024 screening bouts/arm. Rank screen mean net score/min equally across eight opponent/seat cells; ties lexicographic vector, then candidate ID. After all generations, take top eight candidates across all 128 by screening score (same tie policy). Unequal generation-specific noise is part of screening; independent selection reduces selection bias. Evaluate those eight on four separate default-condition selection seeds, all four opponents, both seats, full 300-second bouts: 256 selection bouts/arm. Winner by selection mean net score/min, tie lexicographic vector then ID. Never use held-out shifts or new styles for selection. The three-arm total is 3,840 bouts. No candidate discarded for unfavorable results, except invalid parameter vectors cause a recorded infrastructure error and block completion.

## Existing mind training (no tuning)

Twelve independent trained memories; fixed normal difficulty, tuned policy, configured cognitionBudget=192, existing permitted online learning. Each receives 32 default-condition bouts: four old opponents × two seats × four repetitions. Use a predeclared balanced schedule in seed manifest; carry existing memory only within that cluster, while resetting transient episode state. No seed selection, no source/hyperparameter selection, no training criterion used to pick a favorable mind. Save all twelve final snapshots and lineage. Total 384 bouts. Terminal pending action outcomes remain censored unless already observed legally; do not call a truth/future-informed finish hook to create additional learning.

## Data and freeze

Record task/candidate IDs, all parameter vectors, all seeds, ordered opponent/seat assignment, exact elapsed duration, both scores and score events, focal decision timing summaries, configured work, actual logical-counter scope, memory/RSS telemetry, source/config hashes, failures, and complete selection rankings. Persist after every task; no overwrite of a partial attempt. Reproduction must distinguish recorded nonidentical controller/percept paths from shared randomness.

Training completion freeze includes selected three vectors/compute levels, all twelve trained mind snapshots, fixed teacher-schedule parameters derived from training only, controller/kernel/runner bytes, raw outcomes and full hash manifest. No future file may change these parameters after held-out configs are written. A selected NPC is only best among this finite family/budget, not globally optimal.

The learning, novelty-handoff, metacognitive-control, and workspace-broadcast ablations are separate final study arms announced before held-out execution. Their exact removal/fixed-teacher intervention semantics must be reviewed before final study lock; no new mind mechanism is authorized. The metacognitive teacher schedule is fixed from current-condition training only. Eight final-study arms are anticipated (full + four separate lesions + three conventional), but this training runner does not run lesions or shifts.

## Runtime and stop boundary

Training total 4,224 bouts = 483,840 simulated seconds (3,072 screening ×45 s +768 selection ×300 s +384 mind ×300 s) =14,515,200 focal and up to29,030,400 both-controller decision opportunities,58,060,800 simulation ticks. Approximate resource range must be replaced by outcome-blind infrastructure timing; medians omit simulation/logging/tails. At most eight CPU workers. A >24 CPU-hour or >8 wall-hour estimate is reported before launch; do not silently start a multi-day run. No outcome-driven budget extension, additional search restart, or tuning on eventual shift failure. Freeze and report after bounded training; proceed to later user-authorized milestone stages only under their separate locked protocol.

## Current missing historical diagnostic

The exact historical 40-use/12-miss raw fixture cannot be recovered from the verified archived inventory. It is not a passable endpoint in the present study. Preserve the historical description only; any new or preserved N/S diagnostic must be labeled separately and cannot replace that exact requirement. No final all-criteria-success claim while it remains missing.

Learning ablation will use tested freezeLearning at the common acquired-memory checkpoint, preserving previously learned habits and transient control while blocking further persisted updates. It is not noLearning, which changes habit availability. Workspace delivery cut is a partial broadcast lesion (attention/planner/memory delivery), not a whole-workspace or consciousness-off switch; retained local belief/selector paths are disclosed.
